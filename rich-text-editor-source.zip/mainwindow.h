#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QApplication>
#include <QMainWindow>
#include <QCloseEvent>
#include <QFile>
#include <QFileDialog>
#include <QColorDialog>
#include <QFontDialog>
#include <QDesktopServices>
#include <QUrl>
#include <QApplication>
#include <QTextStream>
#include <QToolTip>
#include <QMessageBox>
#include "finddialog.h"
#include "replacedialog.h"
#include "aboutdialog.h"



QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_actionNew_triggered();
    void on_actionOpen_triggered();
    void on_actionSave_triggered();
    void on_actionSave_As_triggered();
    void on_actionExit_triggered();
    void on_actionCopy_triggered();
    void on_actionCut_triggered();
    void on_actionPaste_triggered();
    void on_actionFind_triggered();
    void on_actionReplace_triggered();
    void on_actionSelect_All_triggered();
    void on_actionZoom_In_triggered();
    void on_actionZoom_Out_triggered();
    void on_actionBold_triggered();
    void on_actionItalic_triggered();
    void on_actionUnderline_triggered();
    void on_actionStrikethrough_triggered();
    void on_actionColor_triggered();
    void on_actionFont_triggered();
    void on_actionHelp_triggered();
    void on_actionAbout_triggered();

    void on_textEdit_textChanged();

    void on_actionUndo_triggered();

    void on_actionRedo_triggered();



    void on_actionCustom_Text_triggered();

    void on_actionAlignToCenter_triggered();

    void on_actionalignToLeft_triggered();

    void on_actionalignToRight_triggered();

    void on_actiontextAlignToJustify_triggered();

    void on_actionAnimals_triggered();

private:
    Ui::MainWindow *ui;

    bool m_fileChanged;
    QString m_path;

    void newFile();
    void openFile();
    void saveFile(QString path);
    void saveFileAs();
    void checkSave();


    // QWidget interface
protected:
    void closeEvent(QCloseEvent *event) override;
};
#endif // MAINWINDOW_H
