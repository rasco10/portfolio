#include "replacedialog.h"
#include "ui_replacedialog.h"

ReplaceDialog::ReplaceDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ReplaceDialog)
{
    ui->setupUi(this);

    init();
    save();
}

ReplaceDialog::~ReplaceDialog()
{
    delete ui;
}

void ReplaceDialog::on_buttonBox_rejected()
{
    reject();
}

void ReplaceDialog::replace()
{
    save();
    accept();
}

void ReplaceDialog::replaceAll()
{
    save();
    m_replaceAll = true;
    accept();
}

//void ReplaceDialog::deleteText()
//{
//    save();
//    accept();
//}

//void ReplaceDialog::deleteAllText()
//{
//    save();
//    accept();
//}

void ReplaceDialog::init()
{
    QPushButton *btnReplace = new QPushButton("Replace", this);
    QPushButton *btnReplaceAll = new QPushButton("Replace All", this);
//    QPushButton *btnDelete = new QPushButton("Delete", this);
//    QPushButton *btnDeleteAll = new QPushButton("Delete All", this);


    ui->buttonBox->addButton(btnReplace, QDialogButtonBox::ButtonRole::ActionRole);
    ui->buttonBox->addButton(btnReplaceAll, QDialogButtonBox::ButtonRole::ActionRole);
//    ui->buttonBox->addButton(btnDelete, QDialogButtonBox::ButtonRole::ActionRole);
//    ui->buttonBox->addButton(btnDeleteAll, QDialogButtonBox::ButtonRole::ActionRole);


    connect(btnReplace, &QPushButton::clicked, this, &ReplaceDialog::replace);
    connect(btnReplaceAll, &QPushButton::clicked, this, &ReplaceDialog::replaceAll);
//    connect(btnDelete, &QPushButton::clicked, this, &ReplaceDialog::deleteText);
//    connect(btnDeleteAll, &QPushButton::clicked, this, &ReplaceDialog::deleteAllText);
}

void ReplaceDialog::save()
{
    m_text = ui->findTxt->text();
    m_replaceText = ui->replaceTxt->text();
    m_replaceAll = false;
}

const QString &ReplaceDialog::replaceText() const
{
    return m_replaceText;
}

const QString &ReplaceDialog::text() const
{
    return m_text;
}

bool ReplaceDialog::all() const
{
    return m_replaceAll;
}

