#include "mainwindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    a.setOrganizationName("3DP");
    a.setOrganizationDomain("https://google.com");
    a.setApplicationName("3DP v0.1.0 Beta");
    a.setApplicationDisplayName("3DP v0.1.0 Beta");
    a.setApplicationVersion("0.1.0 Beta");


    MainWindow w;
    w.show();
    return a.exec();
}
