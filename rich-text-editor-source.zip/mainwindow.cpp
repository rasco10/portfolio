#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setCentralWidget(ui->textEdit);

    m_path = "";
    m_fileChanged = false;
    newFile();
}

MainWindow::~MainWindow()
{
    delete ui;
}




void MainWindow::on_actionNew_triggered()
{
    checkSave();
    newFile();
}

void MainWindow::on_actionOpen_triggered()
{
    checkSave();
    openFile();
}

void MainWindow::on_actionSave_triggered()
{
    saveFile(m_path);
}

void MainWindow::on_actionSave_As_triggered()
{
    saveFileAs();
}

void MainWindow::on_actionExit_triggered()
{
    close();
}


void MainWindow::on_actionUndo_triggered()
{
    ui->textEdit->undo();

}


void MainWindow::on_actionRedo_triggered()
{
    ui->textEdit->redo();

}

void MainWindow::on_actionCopy_triggered()
{
    ui->textEdit->copy();
}

void MainWindow::on_actionCut_triggered()
{
    ui->textEdit->cut();
}

void MainWindow::on_actionPaste_triggered()
{
    ui->textEdit->paste();
}

void MainWindow::on_actionFind_triggered()
{
    FindDialog *findDlg = new FindDialog(this);
    if (!findDlg->exec()) return;

    QTextDocument::FindFlags flags;
    if (findDlg->caseSensitive()) flags = flags | QTextDocument::FindFlag::FindCaseSensitively;
    if (findDlg->entireWord()) flags = flags | QTextDocument::FindFlag::FindWholeWords;
    if (findDlg->findBackwards()) flags = flags | QTextDocument::FindFlag::FindBackward;

    bool value = ui->textEdit->find(findDlg->text(), flags);
    if (!value) QMessageBox::information(this, "Not Found", "'" + findDlg->text() + "' wasn't found");

}

void MainWindow::on_actionReplace_triggered()
{
    ReplaceDialog *replaceDlg = new ReplaceDialog(this);
    if (!replaceDlg->exec()) return;

    if (replaceDlg->all())
    {
        // Replace All
        bool value = ui->textEdit->find(replaceDlg->text());
        QString text = ui->textEdit->toHtml();
        text = text.replace(replaceDlg->text(), replaceDlg->replaceText());
        ui->textEdit->setHtml(text);
        if (!value) QMessageBox::information(this, "Text wasn't found", replaceDlg->text() + " was not found");
        m_fileChanged = true;
    }
    else
    {
        // Replace a single word
        bool value = ui->textEdit->find(replaceDlg->text());
        QTextCursor cursor = ui->textEdit->textCursor();
        cursor.insertHtml(replaceDlg->replaceText());
        if (!value) QMessageBox::information(this, "Text wasn't found", replaceDlg->text() + " was not found");
        m_fileChanged = true;
    }
}

void MainWindow::on_actionSelect_All_triggered()
{
    ui->textEdit->selectAll();
}

void MainWindow::on_actionZoom_In_triggered()
{
    ui->textEdit->zoomIn(1);

}

void MainWindow::on_actionZoom_Out_triggered()
{
    ui->textEdit->zoomOut(1);

}

void MainWindow::on_actionBold_triggered()
{
    QFont font = ui->textEdit->currentFont();
    font.bold() ? font.setBold(false) : font.setBold(true);
    ui->textEdit->setCurrentFont(font);
    m_fileChanged = true;
}

void MainWindow::on_actionItalic_triggered()
{
    QFont font = ui->textEdit->currentFont();
    font.italic() ? font.setItalic(false) : font.setItalic(true);
    ui->textEdit->setCurrentFont(font);
    m_fileChanged = true;
}

void MainWindow::on_actionUnderline_triggered()
{
    QFont font = ui->textEdit->currentFont();
    font.underline() ? font.setUnderline(false) : font.setUnderline(true);
    ui->textEdit->setCurrentFont(font);
    m_fileChanged = true;
}
void MainWindow::on_actionStrikethrough_triggered()
{
    QFont font = ui->textEdit->currentFont();
    font.strikeOut() ? font.setStrikeOut(false) : font.setStrikeOut(true);
    ui->textEdit->setCurrentFont(font);
    m_fileChanged = true;
}



void MainWindow::on_actionColor_triggered()
{
    QColor currentColor = ui->textEdit->currentCharFormat().foreground().color();
    QColor color = QColorDialog::getColor(currentColor, this, "Select a Color");

    ui->textEdit->setTextColor(color);

    currentColor == color ? m_fileChanged = false : true;
}

void MainWindow::on_actionFont_triggered()
{
    bool ok;
    QFont font = QFontDialog::getFont(&ok, ui->textEdit->currentFont(), this, "Choose a Font");
    if (ok) ui->textEdit->setCurrentFont(font);
}

void MainWindow::on_actionHelp_triggered()
{
    QDesktopServices::openUrl(QUrl(QApplication::organizationDomain()));
}

void MainWindow::on_actionAbout_triggered()
{
    AboutDialog *aboutDlg = new AboutDialog(this);
    aboutDlg->exec();
}

void MainWindow::newFile()
{
    ui->textEdit->clear();
    ui->statusbar->showMessage("New File");
    m_path = "";
    m_fileChanged = false;
}

void MainWindow::openFile()
{
    QString path = QFileDialog::getOpenFileName(this, "Open File");
    if (path.isEmpty()) return;

    QFile file(path);
    if (!file.open(QIODevice::ReadOnly))
    {
        QMessageBox::critical(this, "Error", file.errorString());
        return;
    }

    QTextStream stream(&file);
    ui->textEdit->setHtml(stream.readAll());
    file.close();

    m_path = path;
    ui->statusbar->showMessage(m_path);
    m_fileChanged = false;
}

void MainWindow::saveFile(QString path)
{
    if (path.isEmpty()) // if the document itself has no path (i.e hasn't been saved/placed on the disk before
    {
        saveFileAs(); // Save it on disk
        return;
    }

    QFile file(path);
    if (!file.open(QIODevice::WriteOnly))
    {
        QMessageBox::critical(this, "Error", file.errorString());
        ui->statusbar->showMessage("Error, couldn't save file!");
        saveFileAs();
        return;
    }

    QTextStream stream(&file);
    stream << ui->textEdit->toHtml();
    file.close();

    m_path = path;
    ui->statusbar->showMessage(m_path);
    m_fileChanged = false;

}

void MainWindow::saveFileAs()
{
    QString path = QFileDialog::getSaveFileName(this, "Save File");
    if (path.isEmpty()) return;

    saveFile(path);
}

void MainWindow::checkSave()
{
    if (!m_fileChanged) return;

    QMessageBox::StandardButton value = QMessageBox::question(this, "Save File?", "You have unsaved changes, would you like to save them?");

    if (value != QMessageBox::StandardButton::Yes) return;

    if (m_path.isEmpty())
    {
        saveFileAs();
    }
    else
    {
        saveFile(m_path);
    }
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    event->accept();
}



void MainWindow::on_textEdit_textChanged()
{
    m_fileChanged = true;
}





void MainWindow::on_actionCustom_Text_triggered()
{
    ui->textEdit->insertHtml("<font size='40' color='red'><b>T</b><i>est</i><br><br></font>");
    ui->textEdit->insertHtml("<ul><li>Coffee</li><li>Tea</li><li>Water</li></ul>");

}


void MainWindow::on_actionAlignToCenter_triggered()
{
    QTextCursor cursor = ui->textEdit->textCursor();
    if (cursor.hasSelection())
    {
        QTextBlockFormat textBlockFormat = cursor.blockFormat();
        textBlockFormat.setAlignment(Qt::AlignCenter);
        cursor.mergeBlockFormat(textBlockFormat);
        ui->textEdit->setTextCursor(cursor);
    } else return;
}


void MainWindow::on_actionalignToLeft_triggered()
{
    QTextCursor cursor = ui->textEdit->textCursor();
    if (cursor.hasSelection())
    {
        QTextBlockFormat textBlockFormat = cursor.blockFormat();
        textBlockFormat.setAlignment(Qt::AlignLeft);
        cursor.mergeBlockFormat(textBlockFormat);
        ui->textEdit->setTextCursor(cursor);
    } else return;
}


void MainWindow::on_actionalignToRight_triggered()
{
    QTextCursor cursor = ui->textEdit->textCursor();
    if (cursor.hasSelection())
    {
        QTextBlockFormat textBlockFormat = cursor.blockFormat();
        textBlockFormat.setAlignment(Qt::AlignRight);
        cursor.mergeBlockFormat(textBlockFormat);
        ui->textEdit->setTextCursor(cursor);
    } else return;
}


void MainWindow::on_actiontextAlignToJustify_triggered()
{
    QTextCursor cursor = ui->textEdit->textCursor();
    if (cursor.hasSelection())
    {
        QTextBlockFormat textBlockFormat = cursor.blockFormat();
        textBlockFormat.setAlignment(Qt::AlignJustify);
        cursor.mergeBlockFormat(textBlockFormat);
        ui->textEdit->setTextCursor(cursor);
    } else return;
}


void MainWindow::on_actionAnimals_triggered()
{
    ui->textEdit->insertHtml("<ul><li><font size='30' color='red'>Dog</font></li><li><font size='30' color='green'>Cat</font></li><li><font size='30' color='blue'>Bird</font></li></ul>");


}

