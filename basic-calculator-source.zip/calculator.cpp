/****************************************************************************
**
** Copyright (C) 2016 The Qt Company Ltd.
** Contact: https://www.qt.io/licensing/
**
** This file is part of the examples of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** BSD License Usage
** Alternatively, you may use this file under the terms of the BSD license
** as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include "calculator.h"
#include "button.h"

#include <QGridLayout>
#include <QLineEdit>
#include <QtMath>
#include <QKeyEvent>

Calculator::Calculator(QWidget *parent)
    : QWidget(parent), sumSoFar(0.0)
    , factorSoFar(0.0), waitingForOperand(true)
{
// setting up the calculator display
    display = new QLineEdit("0");
    display->setReadOnly(true);
    display->setAlignment(Qt::AlignRight);
    display->setMaxLength(15);
    display->setStyleSheet("background-color: white; color: dark;");

    QFont font = display->font();
    font.setPointSize(font.pointSize() + 8);
    display->setFont(font);

// setting up the calculator buttons
//    Button *changeSignButton = createButton(tr("\302\261"), SLOT(changeSignClicked()));
    Button *backspaceBtn = createButton(tr("Backspace"), SLOT(backspaceClicked()));
    Button *clearBtn = createButton(tr("Clear"), SLOT(clear()));
    backspaceBtn->setStyleSheet("color: white;");
    clearBtn->setStyleSheet("color: white;");

    Button *divideBtn = createButton(tr("\303\267"), SLOT(multiplicativeOperatorClicked()));
    Button *multiplyBtn = createButton(tr("\303\227"), SLOT(multiplicativeOperatorClicked()));
    Button *subtractBtn = createButton(tr("-"), SLOT(additiveOperatorClicked()));
    Button *additionBtn = createButton(tr("+"), SLOT(additiveOperatorClicked()));
    Button *equalBtn = createButton(tr("="), SLOT(equalClicked()));
    Button *pointBtn = createButton(tr("."), SLOT(pointClicked()));

    divideBtn->setStyleSheet("color: orange");
    multiplyBtn->setStyleSheet("color: orange");
    subtractBtn->setStyleSheet("color: orange");
    additionBtn->setStyleSheet("color: orange");
    divideBtn->setStyleSheet("color: orange");
    equalBtn->setStyleSheet("color: white");




    QGridLayout *mainLayout = new QGridLayout;

//    mainLayout->setSizeConstraint(QLayout::SetFixedSize);
    mainLayout->addWidget(display, 0, 0, 1, 4);
    mainLayout->addWidget(backspaceBtn, 1, 0, 1, 2);
    mainLayout->addWidget(clearBtn, 1, 2);
    mainLayout->addWidget(pointBtn, 5, 2);
    mainLayout->addWidget(divideBtn, 1, 3);
    mainLayout->addWidget(multiplyBtn, 2, 3);
    mainLayout->addWidget(subtractBtn, 3, 3);
    mainLayout->addWidget(additionBtn, 4, 3);
    mainLayout->addWidget(equalBtn, 5, 3);



    for (int i = 0; i < NumDigitButtons; ++i) {

        int row = ((9 - i) / 3) + 2;
        int col = ((i - 1) % 3);

        if (i == 0)
        {
          row = 5;
          col = 1;
        }

        digitButtons[i] = createButton(QString::number(i), SLOT(numClicked()));
        mainLayout->addWidget(digitButtons[i], row, col);
    }


    setLayout(mainLayout);

    setWindowTitle(tr("Simple Calculator"));
}

//bool eventFilter(QObject* obj, QEvent* event)
//{
//    if (event->type()==QEvent::KeyPress) {
//            QKeyEvent* key = static_cast<QKeyEvent*>(event);
//            if ( (key->key()==Qt::Key_Enter) || (key->key()==Qt::Key_Return) ) {
//                //Enter or return was pressed
//            } else {
//                return QObject::eventFilter(obj, event);
//            }
//            return true;
//        } else {
//            return QObject::eventFilter(obj, event);
//        }
//        return false;
//}


//void Calculator::keyReleaseEvent(QKeyEvent *event)
//{
////   switch (event->key())
////    {
////        case Qt::Key_0:
////            Calculator::numClicked();
////        break;
////        case Qt::Key_1:
////            Calculator::numClicked();
////        break;
////        case Qt::Key_2:
////            Calculator::numClicked();
////        break;
////        case Qt::Key_3:
////            Calculator::numClicked();
////        break;
////    }

//}


void Calculator::numClicked()
{
    Button *clickedButton = qobject_cast<Button *>(sender());
    int digitValue = clickedButton->text().toInt();
    if (display->text() == "0" && digitValue == 0.0)
        return;

    if (waitingForOperand) {
        display->clear();
        waitingForOperand = false;
    }
    display->setText(display->text() + QString::number(digitValue));
}

void Calculator::unaryOperatorClicked()
{
    Button *clickedButton = qobject_cast<Button *>(sender());
    QString clickedOperator = clickedButton->text();
    double operand = display->text().toDouble();
    double result = 0.0;

    if (clickedOperator == tr("Sqrt")) {
        if (operand < 0.0) {
            abortOperation();
            return;
        }
        result = std::sqrt(operand);
    } else if (clickedOperator == tr("x\302\262")) {
        result = std::pow(operand, 2.0);
    } else if (clickedOperator == tr("1/x")) {
        if (operand == 0.0) {
            abortOperation();
            return;
        }
        result = 1.0 / operand;
    }
    display->setText(QString::number(result));
    waitingForOperand = true;
}

void Calculator::additiveOperatorClicked()
{
    Button *clickedButton = qobject_cast<Button *>(sender());
    if (!clickedButton)
      return;
    QString clickedOperator = clickedButton->text();
    double operand = display->text().toDouble();

    if (!pendingMultiplicativeOperator.isEmpty()) {
        if (!calculate(operand, pendingMultiplicativeOperator)) {
            abortOperation();
            return;
        }
        display->setText(QString::number(factorSoFar));
        operand = factorSoFar;
        factorSoFar = 0.0;
        pendingMultiplicativeOperator.clear();
    }

    if (!pendingAdditiveOperator.isEmpty()) {
        if (!calculate(operand, pendingAdditiveOperator)) {
            abortOperation();
            return;
        }
        display->setText(QString::number(sumSoFar));
    } else {
        sumSoFar = operand;
    }

    pendingAdditiveOperator = clickedOperator;
    waitingForOperand = true;
}

void Calculator::multiplicativeOperatorClicked()
{
    Button *clickedButton = qobject_cast<Button *>(sender());
    if (!clickedButton)
      return;
    QString clickedOperator = clickedButton->text();
    double operand = display->text().toDouble();

    if (!pendingMultiplicativeOperator.isEmpty()) {
        if (!calculate(operand, pendingMultiplicativeOperator)) {
            abortOperation();
            return;
        }
        display->setText(QString::number(factorSoFar));
    } else {
        factorSoFar = operand;
    }

    pendingMultiplicativeOperator = clickedOperator;
    waitingForOperand = true;
}

void Calculator::equalClicked()
{
    double operand = display->text().toDouble();

    if (!pendingMultiplicativeOperator.isEmpty()) {
        if (!calculate(operand, pendingMultiplicativeOperator)) {
            abortOperation();
            return;
        }
        operand = factorSoFar;
        factorSoFar = 0.0;
        pendingMultiplicativeOperator.clear();
    }
    if (!pendingAdditiveOperator.isEmpty()) {
        if (!calculate(operand, pendingAdditiveOperator)) {
            abortOperation();
            return;
        }
        pendingAdditiveOperator.clear();
    } else {
        sumSoFar = operand;
    }

    display->setText(QString::number(sumSoFar));
    sumSoFar = 0.0;
    waitingForOperand = true;
}

void Calculator::pointClicked()
{
    if (waitingForOperand)
        display->setText("0");
    if (!display->text().contains('.'))
        display->setText(display->text() + tr("."));
    waitingForOperand = false;
}

void Calculator::changeSignClicked()
{
    QString text = display->text();
    double value = text.toDouble();

    if (value > 0.0) {
        text.prepend(tr("-"));
    } else if (value < 0.0) {
        text.remove(0, 1);
    }
    display->setText(text);
}

void Calculator::backspaceClicked()
{
    if (waitingForOperand)
        return;

    QString text = display->text();
    text.chop(1);
    if (text.isEmpty()) {
        text = "0";
        waitingForOperand = true;
    }
    display->setText(text);
}


void Calculator::clear()
{
    sumSoFar = 0.0;
    factorSoFar = 0.0;
    pendingAdditiveOperator.clear();
    pendingMultiplicativeOperator.clear();
    display->setText("0");
    waitingForOperand = true;
}

Button *Calculator::createButton(const QString &text, const char *member)
{
    Button *button = new Button(text);
    connect(button, SIGNAL(clicked()), this, member);
    return button;
}

void Calculator::abortOperation()
{
    clear();
    display->setText(tr("####"));
}

bool Calculator::calculate(double rightOperand, const QString &pendingOperator)
{
    if (pendingOperator == tr("+")) {
        sumSoFar += rightOperand;
    } else if (pendingOperator == tr("-")) {
        sumSoFar -= rightOperand;
    } else if (pendingOperator == tr("\303\227")) {
        factorSoFar *= rightOperand;
    } else if (pendingOperator == tr("\303\267")) {
        if (rightOperand == 0.0)
            return false;
        factorSoFar /= rightOperand;
    }
    return true;
}
