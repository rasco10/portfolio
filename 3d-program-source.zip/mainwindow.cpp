#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QStringList>
#include <QStringListModel>
#include <QCheckBox>
#include <QStandardItemModel>
#include <QStandardItem>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    glWidget = new GLWidget();


    xSlider = createSlider();
    ySlider = createSlider();
    zSlider = createSlider();



//    QVBoxLayout *mainLayout = new QVBoxLayout;
//    QHBoxLayout *container = new QHBoxLayout;
//    container->addWidget(glWidget);
//    container->addWidget(xSlider);
//    container->addWidget(ySlider);
//    ui->horizontalLayout->addWidget(zSlider);
    ui->viewportLayout->addWidget(glWidget); // add the QOpenGLWidget into the main layout: our horizontal layout

//    QStringList *stringList = new QStringList();
//    stringList->append("3D Logo");
//    QStringListModel *listModel = new QStringListModel(*stringList, NULL);
//     ui->objectsListView->setModel(listModel);

//     QStandardItem *standardItem = new QStandardItem();
//     standardItem->setCheckable( true );
//     standardItem->setCheckState( Qt::Checked );
//     glWidget->m_isObjectVisible = true;
//     standardItem->setText("3dobjectname(editable)");


//     QStandardItemModel *standardItemModel = new QStandardItemModel();
//     standardItemModel->setItem( 0,0,  standardItem );
//     ui->objectsListView->setModel( standardItemModel );





//    QWidget *w = new QWidget;
//    w->setLayout(container);
//    mainLayout->addWidget(w);

//    setLayout(mainLayout);

    xSlider->setValue(15 * 16);
    ySlider->setValue(345 * 16);
    zSlider->setValue(0 * 16);

    setWindowTitle(tr("3DP Inc. v0.1"));

    connect(xSlider, &QSlider::valueChanged, glWidget, &GLWidget::setXRotation);
    connect(glWidget, &GLWidget::xRotationChanged, xSlider, &QSlider::setValue);
    connect(ySlider, &QSlider::valueChanged, glWidget, &GLWidget::setYRotation);
    connect(glWidget, &GLWidget::yRotationChanged, ySlider, &QSlider::setValue);
    connect(zSlider, &QSlider::valueChanged, glWidget, &GLWidget::setZRotation);
    connect(glWidget, &GLWidget::zRotationChanged, zSlider, &QSlider::setValue);
//    connect(standardItem, &GLWidget::stdItemCheckStatusChanged, glWidget, &GLWidget::setStdItemCheckStatus);

}

MainWindow::~MainWindow()
{
    delete ui;
}





QSlider *MainWindow::createSlider()
{
    QSlider *slider = new QSlider(Qt::Vertical);
    slider->setRange(0, 360 * 16);
    slider->setSingleStep(16);
    slider->setPageStep(15 * 16);
    slider->setTickInterval(15 * 16);
    slider->setTickPosition(QSlider::TicksRight);
    return slider;
}

void MainWindow::keyPressEvent(QKeyEvent *e)
{

    if (e->key() == Qt::Key_Escape)
        close();
    else
        QWidget::keyPressEvent(e);
}

