#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QLabel>
#include <QSlider>
#include <QKeyEvent>


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE
#include "glwidget.h"



//class GLWidget;
//class QSlider;
//class QPushButton;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void keyPressEvent(QKeyEvent *event) override;

private:
    Ui::MainWindow *ui;
    QKeyEvent* e;

    QSlider *createSlider();

    GLWidget *glWidget;

    QSlider *xSlider;
    QSlider *ySlider;
    QSlider *zSlider;
    QLabel xSliderLabel;
    QSlider *ySliderLabel;
    QSlider *zSliderLabel;
};
#endif // MAINWINDOW_H
